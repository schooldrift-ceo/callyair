<?php
	session_start();
?>
<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>CallyAir- Airline Agency</title>
        <link rel="stylesheet" href="inc/bootstrap/css/bootstrap.min.css" />
        <link rel="stylesheet" href="styles/themes/default/stylesheet.css" /> 
       <link rel="alternate stylesheet" type="text/css"  title="02" href="styles/themes/style02/stylesheet02.css" />
        <link rel="alternate stylesheet" type="text/css"  title="03" href="styles/themes/style03/stylesheet03.css" />
        <link rel="alternate stylesheet" type="text/css"  title="04" href="styles/themes/style04/stylesheet04.css" />
        <link rel="alternate stylesheet" type="text/css"  title="05" href="styles/themes/style05/stylesheet05.css" />
        <link rel="alternate stylesheet" type="text/css"  title="06" href="styles/themes/style06/stylesheet06.css" />
        <link rel="alternate stylesheet" type="text/css"  title="07" href="styles/themes/style07/stylesheet07.css" />
        <link rel="alternate stylesheet" type="text/css"  title="08" href="styles/themes/style08/stylesheet08.css" />
        <link rel="alternate stylesheet" type="text/css"  title="09" href="styles/themes/style09/stylesheet09.css" />
        <link rel="alternate stylesheet" type="text/css"  title="10" href="styles/themes/style10/stylesheet10.css" />
        <link rel="alternate stylesheet" type="text/css"  title="11" href="styles/themes/style11/stylesheet11.css" />
        <link rel="alternate stylesheet" type="text/css"  title="12" href="styles/themes/style12/stylesheet12.css" />
        <link rel="alternate stylesheet" type="text/css"  title="13" href="styles/themes/style13/stylesheet13.css" />
        <link rel="alternate stylesheet" type="text/css"  title="14" href="styles/themes/style14/stylesheet14.css" />
        <link rel="alternate stylesheet" type="text/css"  title="15" href="styles/themes/style15/stylesheet15.css" />
        <script src="inc/js/styleswitch.js" type="text/javascript">
        </script>
        <link rel="stylesheet" href="styles/flexslider.css" />
        <link rel="stylesheet" href="styles/fontawesome/font-awesome.min.css" />
        <link rel="stylesheet" href="styles/jquery-ui-1.10.3.custom.min.css" />
        <link rel="stylesheet" href="styles/mi-slider.css" />	
        <link rel="stylesheet" href="styles/chosen.css" />	
        <link rel="stylesheet" href="styles/rangeslider-classic.css" />
        <link rel="stylesheet" href="inc/elegant-font/style.css" />
     <link rel="stylesheet" href="demo/switcher.css" />
    </head>
    <body>
        <div id="site">
            <header id="header" class="wide-fat">
                <div class="container">
                    <div class="col-xs-12 col-sm-2 no-margin">
                        <div class="branding">
                            <h1 class="site-title">
                                <a href="#"><img src="images/site-logo.png" alt="Traveline" /> <span>Cally<span class="higlight">Air</span></span></a>
                            </h1>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-10 no-margin">
                        <div id="main-menu">
                            <nav class="navigation">
                                <ul class="hidden-xs hidden-sm hidden-md">
                                    <li class="menu-item about-us">
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="icon_pin"></i> Book a Flight</a>
                                        </li>
                                    <li class="menu-item destinations">
                                        <a href="booking.php"><i class="icon_group"></i> Manage Booking</a>
                                    </li>
                                    <li class="menu-item our-travel">
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="icon_globe_alt"></i> Online Check-in</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a data-toggle="modal" data-target="#AgentBox" href="#"><i class="fa fa-unlock"></i> Agent Login</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a data-toggle="modal" data-target="#CustomerBox" href="#"><i class="fa fa-lock"></i> Customer Login</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a href="phpmyadmin"><i class="icon_ribbon"></i> Admin Login</a>
                                    </li>
                                </ul></nav></div>
                    </div>
                </div>
            </header>
            <div class="modal fade" id="AgentBox" tabindex="-1" role="dialog"  aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <form action="\php\agent_confirm.php" method="post" onsubmit="return validation_agent()" name="agentlogin">
                                  <span>Agent Login</span>
                                <div class=" field-row">
                                    <input  placeholder="Username" id="user" name="user">
                                    <input  type="password" placeholder="Password" name="pass" id="pass">
                                    <div class="custom-checkbox-holder">
                                        <input class="custom-checkbox" type="checkbox" >
                                        <span>Remember me on this computer.</span>
                                    </div>
                                </div>
                                <button type="submit" class="button green" name="">Login Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="modal fade" id="CustomerBox" tabindex="-1" role="dialog"  aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <form action="\php\customer.php" method="post" onsubmit="return validation_customer()" name="customerlogin">
                                <span>Customer Login</span>
                                <div class=" field-row">
                                    <input  placeholder="Username" id="user" name="user">
                                    <input  type="password" placeholder="Password" id="pass" name="pass">
                                    <div class="custom-checkbox-holder">
                                        <input class="custom-checkbox" type="checkbox" >
                                        <span>Remember me on this computer.</span>
                                    </div>
                                </div>
                                <button type="submit" class="button green">Login Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <section id="featured" class="wide-fat">
                <div class="featured-inner">
                    <div class="slider">
                        <div id="top-slider" class="flexslider">
                            <ul class="slides">
                                <li>
                                    <img src="images/content/airplane1.jpg" alt="Featured Image" />
                                </li>
                                <li>
                                    <img src="images/content/airplane%202.jpg" alt="Featured Image" />
                                </li>
                                <li>
                                    <img src="images/content/airplane%203.jpg" alt="Featured Image" />
                                </li>
                            </ul>
                            <div class="opener-area">
                                <a  href="#" class="open-btn open-close-btn"><i class="fa fa-chevron-circle-right"></i></a>
                                <ul class="social-icons vertical">
                                    <li><a href="#" class="fa fa-facebook"></a></li>
                                    <li><a href="#" class="fa fa-twitter"></a></li>
                                    <li><a href="#" class="fa fa-rss"></a></li>
                                    <li><a href="#" class="fa fa-vimeo-square"></a></li>
                                </ul>
                            </div>
                            <div class="featured-overlay">
                                <a id="close-form" href="#" class="button close open-close-btn"><i class="icon_close_alt2"></i></a>
                                <div class="featured-overlay-inner">
                                      <label id="lblGreetings"> </label>
                                    <form class="location-search" method="post" action="bookflight.php">
                                        <div class="search-field">
                                            <div class="destination-field">
                                                <label for="pay_in">Pay In:</label>
                                                  <select id="pay_in" class="pay_in" name="pay_in">
                                                  <option value="Naira">Naira</option>
                                                  <option value="Dollar">Dollar</option>
                                                  <option value="Pound">Pound</option>
                                                </select></div>
                                        </div>
                                        <div class="search-field">
                                            <div class="col-field-left">
                                                <label for="from">From:</label>
                                                <br />
                                                 <select id="from" class="from" name="from">
                                                <option value="location">Enter location</option>
                                                  <option value="Abuja">Abuja</option>
                                                  <option value="Calabar">Calabar</option>
                                                  <option value="Lagos">Lagos</option>
                                                </select>

                                            </div>
                                            <div class="col-field-right">
                                                <label for="to">To:</label>
                                            <br />
                                                 <select id="to" class="to" name="to">
                                                <option value="location">Enter Drop off location</option>
                                                  <option value="Kano">Kano</option>
                                                  <option value="Ebonyi">Ebonyi</option>
                                                  <option value="Delta">Delta</option>
                                                </select>

                                            </div>							
                                        </div>
                                        <div class="search-field">
                                            <div class="search_field">
                                                <label for="dep_date">Date of Departure:</label>
                                                <br />
                                                 <input id="dep_date" type="date" name="dep_date" />
                                            </div>
                                        </div>
                                        <div class="search-field">
                                            <div class="search_field">
                                                <label>Enter the Class:</label>
                                                <br />
                                                 <select class="class" name="class" id="class">
                                                  <option value="economy">Economy</option>
                                                  <option value="business">Business</option>
                                                  </select>

                                            </div>
                                        </div>
                                        <div class="search-field">	
                                            <div class="search-field">
                                                <div class="voucher-field">
                                                    <label for="vouch">Reedem Voucher</label>
                                                    <br />
                                                    <input id="vouch" type="text" name="vouch" />
                                                </div>
                                            </div>
                                            <div class="search-field">
                                                <div class="search-field">
                                                    <div class="adult-left">
                                                        <label for="no_of_pass">Number of Passengers (Adult & Children)</label>
                                                        <br />
                                                        <div class="quantity">
                                                            <input id="no_of_pass" class="qty" type="number" name="no_of_pass"  />
                                                        </div>
                                                    </div>	
                                                </div>		
                                                
                                            </div>	</div>
                                        <div class="search-field">
                                            <input type="submit" class="button wide-fat" value="Continue" name="Search" />
                                        </div>		
                                    </form>
                                    <div class="social-networks">
                                        <ul>
                                            <li class="facebook"><a href="#"><i class="social_facebook"></i></a></li>
                                            <li class="twitter"><a href="#"><i class="social_twitter"></i></a></li>
                                            <li class="vimeo"><a href="#"><i class="social_vimeo"></i></a></li>
                                            <li class="rss"><a href="#"><i class="social_rss"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
</div></div>				
</div></section><section id="about-us" class="homepage section wide-fat">
                <div class="container">
                    <article id="post-1" class="about-us section-intro">
                        <h1 class="page-title">Our <span class="higlight">Flight Locations</span></h1>
                        </article>
                    <div class="about-details grid col-3">
                        <div class="row">
                            <div class="col-md-4 col-sm-4 about-detail-1 honey-moon">
                                <article>
                                    <h2>Lagos</h2>
                                   
                                </article>
                            </div>
                            <div class="col-md-4 col-sm-4 about-detail-2 explore-nature">
                                <article>
                                    <h2>Abuja</h2>
                                    </article>
                            </div>
                            <div class="col-md-4 col-sm-4 about-detail-3 amazing-travel">
                                <article>
                                    <h2>Calabar</h2>
                                    </article>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
<footer id="footer" class="widefat">
                <div class="container">
                    <div class="footer-inner">
                        <p class="credit">CallyAir-2022</p>
                    </div></div></footer></div>
        <script src="inc/js/jquery-1.10.2.min.js"></script>
        <script src="inc/js/jquery-migrate-1.2.1.js"></script>
        <script src="inc/js/modernizr.custom.63321.js"></script>
        <script type="text/javascript" src="inc/js/jquery.flexslider-min.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.catslider.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.ui.datepicker.min.js"></script>	
        <script type="text/javascript" src="inc/js/masonry.min.js"></script>	
        <script type="text/javascript" src="inc/js/increase-decrease-qty.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.mixitup.min.js"></script>	
        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
        <script type="text/javascript" src="inc/js/google-map-infobox.js"></script>		
        <script type="text/javascript" src="inc/js/jquery.fitmaps.js"></script>	
        <script type="text/javascript" src="inc/js/chosen.jquery.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.screwdefaultbuttonsV2.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.mousewheel.min.js"></script>	
        <script type="text/javascript" src="inc/js/jQRangeSlider-min.js"></script>	
        <script type="text/javascript" src="inc/bootstrap/js/bootstrap.min.js"></script>		
        <script type="text/javascript" src="inc/js/jquery.raty.min.js"></script>	
        <script type="text/javascript" src="inc/js/custom.js"></script>	
        <script>
    var myDate = new Date();
    var hrs = myDate.getHours();

    var greet;

    if (hrs < 12)
        greet = 'Good Morning';
    else if (hrs >= 12 && hrs <= 17)
        greet = 'Good Afternoon';
    else if (hrs >= 17 && hrs <= 24)
        greet = 'Good Evening';

    document.getElementById('lblGreetings').innerHTML =
        '<b>' + greet + '</b> Friend';
</script>
<script>
  function validation_agent()  
            {  
                var id=document.agentlogin.user.value;  
                var ps=document.agentlogin.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("User Name and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
    function validation_customer()  
            {  
                var id=document.customerlogin.user.value;  
                var ps=document.customerlogin.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("User Name and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
  
        </script>
    </body>
</html>