<?php
	session_start();
?>
<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>CallyAir- Airline Agency</title>
        <link rel="stylesheet" href="inc/bootstrap/css/bootstrap.min.css" />
         <link rel="stylesheet" href="bookflight.css" /> 
       <link rel="alternate stylesheet" type="text/css"  title="02" href="styles/themes/style02/stylesheet02.css" />
        <link rel="alternate stylesheet" type="text/css"  title="03" href="styles/themes/style03/stylesheet03.css" />
        <link rel="alternate stylesheet" type="text/css"  title="04" href="styles/themes/style04/stylesheet04.css" />
        <link rel="alternate stylesheet" type="text/css"  title="05" href="styles/themes/style05/stylesheet05.css" />
        <link rel="alternate stylesheet" type="text/css"  title="06" href="styles/themes/style06/stylesheet06.css" />
        <link rel="alternate stylesheet" type="text/css"  title="07" href="styles/themes/style07/stylesheet07.css" />
        <link rel="alternate stylesheet" type="text/css"  title="08" href="styles/themes/style08/stylesheet08.css" />
        <link rel="alternate stylesheet" type="text/css"  title="09" href="styles/themes/style09/stylesheet09.css" />
        <link rel="alternate stylesheet" type="text/css"  title="10" href="styles/themes/style10/stylesheet10.css" />
        <link rel="alternate stylesheet" type="text/css"  title="11" href="styles/themes/style11/stylesheet11.css" />
        <link rel="alternate stylesheet" type="text/css"  title="12" href="styles/themes/style12/stylesheet12.css" />
        <link rel="alternate stylesheet" type="text/css"  title="13" href="styles/themes/style13/stylesheet13.css" />
        <link rel="alternate stylesheet" type="text/css"  title="14" href="styles/themes/style14/stylesheet14.css" />
        <link rel="alternate stylesheet" type="text/css"  title="15" href="styles/themes/style15/stylesheet15.css" />
        <script src="inc/js/styleswitch.js" type="text/javascript">
        </script>
        <link rel="stylesheet" href="styles/flexslider.css" />
        <link rel="stylesheet" href="styles/fontawesome/font-awesome.min.css" />
        <link rel="stylesheet" href="styles/jquery-ui-1.10.3.custom.min.css" />
        <link rel="stylesheet" href="styles/mi-slider.css" />	
        <link rel="stylesheet" href="styles/chosen.css" />	
        <link rel="stylesheet" href="styles/rangeslider-classic.css" />
        <link rel="stylesheet" href="inc/elegant-font/style.css" />
     <link rel="stylesheet" href="demo/switcher.css" />
        <style>
			input {
    			border: 1.5px solid #030337;
    			border-radius: 4px;
    			padding: 7px 30px;
			}
			input[type=submit] {
				background-color: #030337;
				color: white;
    			border-radius: 4px;
    			padding: 7px 45px;
    			margin: 0px 0px
			}
			input[type=date] {
				border: 1.5px solid #030337;
    			border-radius: 4px;
    			padding: 5.5px 44.5px;
			}
			select {
    			border: 1.5px solid #030337;
    			border-radius: 4px;
    			padding: 6.5px 75.5px;
			}
		</style>
    </head>
    <body>
        <div id="site">
            <header id="header" class="wide-fat">
                <div class="container">
                    <div class="col-xs-12 col-sm-2 no-margin">
                        <div class="branding">
                            <h1 class="site-title">
                                <a href="index.php"><img src="images/site-logo.png" alt="Traveline" /> <span>Cally<span class="higlight">Air</span></span></a>
                            </h1>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-10 no-margin">
                        <div id="main-menu">
                            <nav class="navigation">
                                <ul class="hidden-xs hidden-sm hidden-md">
                                    <li class="menu-item destinations">
                                        <a href="bookflight.php"><i class="icon_group"></i> Manage Booking</a>
                                    </li>
                                    <li class="menu-item our-travel">
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="icon_globe_alt"></i> Online Check-in</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a data-toggle="modal" data-target="#AgentBox" href="#"><i class="fa fa-unlock"></i> Agent Login</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a data-toggle="modal" data-target="#CustomerBox" href="#"><i class="fa fa-lock"></i> Customer Login</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a href="phpmyadmin"><i class="icon_ribbon"></i> Admin Login</a>
                                    </li>
                                </ul></nav></div>
                    </div>
                </div>
            </header>
            <div class="modal fade" id="AgentBox" tabindex="-1" role="dialog"  aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <form action="\php\agent.php" method="post" onsubmit="return validation_agent()" name="agentlogin">
                                  <span>Agent Login</span>
                                <div class=" field-row">
                                    <input  placeholder="Username" id="user" name="user">
                                    <input  type="password" placeholder="Password" name="pass" id="pass">
                                    <div class="custom-checkbox-holder">
                                        <input class="custom-checkbox" type="checkbox" >
                                        <span>Remember me on this computer.</span>
                                    </div>
                                </div>
                                <button type="submit" class="button green" name="">Login Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="modal fade" id="CustomerBox" tabindex="-1" role="dialog"  aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <form action="\php\customer.php" method="post" onsubmit="return validation_customer()" name="customerlogin">
                                <span>Customer Login</span>
                                <div class=" field-row">
                                    <input  placeholder="Username" id="user" name="user">
                                    <input  type="password" placeholder="Password" id="pass" name="pass">
                                    <div class="custom-checkbox-holder">
                                        <input class="custom-checkbox" type="checkbox" >
                                        <span>Remember me on this computer.</span>
                                    </div>
                                </div>
                                <button type="submit" class="button green">Login Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <section id="book" class="wide-fat">
                <div class="book-inner">
                    <div class="slider">
                        <div id="top-slider" class="flexslider">
                            <ul class="slides">
                                <li>
                                    <img src="images/content/airplane1.jpg" alt="Featured Image" />
                                </li>
                                <li>
                                    <img src="images/content/airplane%202.jpg" alt="Featured Image" />
                                </li>
                                <li>
                                    <img src="images/content/airplane%203.jpg" alt="Featured Image" />
                                </li>
                            </ul></div>
                      <div class="book-overlay">
                                <div class="book-overlay-inner">
                                    <h2><center>AVAILABLE FLIGHT MATCHING YOUR REQUEST</center></h2>
                                  <br>
<?php
			if(isset($_POST['Search']))
			{
				$data_missing=array();
				if(empty($_POST['pay_in']))
				{
					$data_missing[]='pay_in';
				}
				else
				{
					$pay_in=$_POST['pay_in'];
				}
				if(empty($_POST['from']))
				{
					$data_missing[]='from';
				}
				else
				{
					$from=$_POST['from'];
				}
                if(empty($_POST['to']))
				{
					$data_missing[]='to';
				}
				else
				{
					$to=$_POST['to'];
				}

				if(empty($_POST['dep_date']))
				{
					$data_missing[]='Departure Date';
				}
				else
				{
					$dep_date=trim($_POST['dep_date']);
				}
                if(empty($_POST['class']))
				{
					$data_missing[]='Class';
				}
				else
				{
					$class=trim($_POST['class']);
				}

				if(empty($_POST['vouch']))
                {
                    $data_missing[]='vouch';
                }
                else
                {
                    $voucher =trim($_POST['vouch']);
                }
                if(empty($_POST['no_of_pass']))
				{
					$data_missing[]='no_of_pass';
				}
				else
				{
					$no_of_pass=trim($_POST['no_of_pass']);
				}
				if(empty($data_missing))
				{
					$_SESSION['no_of_pass']=$no_of_pass;
					$_SESSION['class']=$class;
					$count=1;
					$_SESSION['count']=$count;
					$_SESSION['journey_date']=$dep_date;
					require_once('php/connection.php');
					if($class=="economy")
					{
						$query="SELECT flight_no,payin,from_city,to_city,departure_date,departure_time,arrival_date,arrival_time,price_economy FROM available_flight where from_city=? and to_city=? and departure_date=? and seats_economy>=? ORDER BY  departure_time";
						$stmt=mysqli_prepare($con,$query);
						mysqli_stmt_bind_param($stmt,"sssi",$from,$to,$dep_date,$no_of_pass);
						mysqli_stmt_execute($stmt);
						mysqli_stmt_bind_result($stmt,$flight_no,$payin,$from_city,$to_city,$departure_date,$departure_time,$arrival_date,$arrival_time,$price_economy);
						mysqli_stmt_store_result($stmt);
						if(mysqli_stmt_num_rows($stmt)==0)
						{
							echo "<h3>No flights are available !</h3>";
						}
						else
						{
							echo "<form action=\"ticketing.php\" method=\"post\">";
							echo "<table cellpadding=\"10\"";
							echo "<tr><th>Flight No.</th>
							<th>Origin</th>
							<th>Destination</th>
							<th>Departure Date</th>
							<th>Departure Time</th>
							<th>Arrival Date</th>
							<th>Arrival Time</th>
							<th>Price(Economy)</th>
							<th>Select</th>
							</tr>";
							while(mysqli_stmt_fetch($stmt)) {
        						echo "<tr>
        						<td>".$flight_no."</td>
        						<td>".$from_city."</td>
								<td>".$to_city."</td>
								<td>".$departure_date."</td>
								<td>".$departure_time."</td>
								<td>".$arrival_date."</td>
								<td>".$arrival_time."</td>
								<td>".$price_economy."</td>
								<td><input type=\"radio\" name=\"select_flight\" value=\"".$flight_no."\"></td>
        						</tr>";
    						}
    						echo "</table> <br>";
    						echo "<input type=\"submit\" value=\"Select Flight\" name=\"Select\">";
    						echo "</form>";
    					}
					}
					else if($class="business")
					{
						$query="SELECT flight_no,payin,from_city,to_city,departure_date,departure_time,arrival_date,arrival_time,price_business FROM available_flight where from_city=? and to_city=? and departure_date=? and seats_business>=? ORDER BY  departure_time";
						$stmt=mysqli_prepare($con,$query);
						mysqli_stmt_bind_param($stmt,"sssi",$from,$to,$dep_date,$no_of_pass);
						mysqli_stmt_execute($stmt);
						mysqli_stmt_bind_result($stmt,$flight_no,$payin,$from_city,$to_city,$departure_date,$departure_time,$arrival_date,$arrival_time,$price_business);
						mysqli_stmt_store_result($stmt);
						if(mysqli_stmt_num_rows($stmt)==0)
						{
							echo "<h3>No flights are available !</h3>";
						}
						else
						{
							echo "<form action=\"ticketing.php\" method=\"post\">";
							echo "<table cellpadding=\"10\"";
							echo "<tr><th>Flight No.</th>
							<th>Origin</th>
							<th>Destination</th>
							<th>Departure Date</th>
							<th>Departure Time</th>
							<th>Arrival Date</th>
							<th>Arrival Time</th>
							<th>Price(Business)</th>
							<th>Select</th>
							</tr>";
							while(mysqli_stmt_fetch($stmt)) {
        						echo "<tr>
        						<td>".$flight_no."</td>
        						<td>".$from_city."</td>
								<td>".$to_city."</td>
								<td>".$departure_date."</td>
								<td>".$departure_time."</td>
								<td>".$arrival_date."</td>
								<td>".$arrival_time."</td>
								<td>&#8358; ".$price_business."</td>
								<td><input type=\"radio\" name=\"select_flight\" value=".$flight_no."></td>
        						</tr>";
    						}
    						echo "</table> <br>";
    						echo "<input type=\"submit\" value=\"Select Flight\" name=\"Select\">";
    						echo "</form>";
    					}
					}	
					mysqli_stmt_close($stmt);
					mysqli_close($con);
				}
				else
				{
					echo "The following data fields were empty! <br>";
					foreach($data_missing as $missing)
					{
						echo $missing ."<br>";
					}
				}
			}
			else
			{
				echo "Search request not received";
			}
		?>
                <script src="inc/js/jquery-1.10.2.min.js"></script>
        <script src="inc/js/jquery-migrate-1.2.1.js"></script>
        <script src="inc/js/modernizr.custom.63321.js"></script>
        <script type="text/javascript" src="inc/js/jquery.flexslider-min.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.catslider.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.ui.datepicker.min.js"></script>	
        <script type="text/javascript" src="inc/js/masonry.min.js"></script>	
        <script type="text/javascript" src="inc/js/increase-decrease-qty.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.mixitup.min.js"></script>	
        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
        <script type="text/javascript" src="inc/js/google-map-infobox.js"></script>		
        <script type="text/javascript" src="inc/js/jquery.fitmaps.js"></script>	
        <script type="text/javascript" src="inc/js/chosen.jquery.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.screwdefaultbuttonsV2.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.mousewheel.min.js"></script>	
        <script type="text/javascript" src="inc/js/jQRangeSlider-min.js"></script>	
        <script type="text/javascript" src="inc/bootstrap/js/bootstrap.min.js"></script>		
        <script type="text/javascript" src="inc/js/jquery.raty.min.js"></script>	
        <script type="text/javascript" src="inc/js/custom.js"></script>	
        <script>
    var myDate = new Date();
    var hrs = myDate.getHours();

    var greet;

    if (hrs < 12)
        greet = 'Good Morning';
    else if (hrs >= 12 && hrs <= 17)
        greet = 'Good Afternoon';
    else if (hrs >= 17 && hrs <= 24)
        greet = 'Good Evening';

    document.getElementById('lblGreetings').innerHTML =
        '<b>' + greet + '</b> Friend';
</script>
<script>
  function validation_agent()  
            {  
                var id=document.agentlogin.user.value;  
                var ps=document.agentlogin.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("User Name and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
    function validation_customer()  
            {  
                var id=document.customerlogin.user.value;  
                var ps=document.customerlogin.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("User Name and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
  
                </script>
    </body>
</html>