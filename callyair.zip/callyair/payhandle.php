<?php
	session_start();
?>
<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>CallyAir- Airline Agency</title>
        <link rel="stylesheet" href="inc/bootstrap/css/bootstrap.min.css" />
         <link rel="stylesheet" href="bookflight.css" /> 
       <link rel="alternate stylesheet" type="text/css"  title="02" href="styles/themes/style02/stylesheet02.css" />
        <link rel="alternate stylesheet" type="text/css"  title="03" href="styles/themes/style03/stylesheet03.css" />
        <link rel="alternate stylesheet" type="text/css"  title="04" href="styles/themes/style04/stylesheet04.css" />
        <link rel="alternate stylesheet" type="text/css"  title="05" href="styles/themes/style05/stylesheet05.css" />
        <link rel="alternate stylesheet" type="text/css"  title="06" href="styles/themes/style06/stylesheet06.css" />
        <link rel="alternate stylesheet" type="text/css"  title="07" href="styles/themes/style07/stylesheet07.css" />
        <link rel="alternate stylesheet" type="text/css"  title="08" href="styles/themes/style08/stylesheet08.css" />
        <link rel="alternate stylesheet" type="text/css"  title="09" href="styles/themes/style09/stylesheet09.css" />
        <link rel="alternate stylesheet" type="text/css"  title="10" href="styles/themes/style10/stylesheet10.css" />
        <link rel="alternate stylesheet" type="text/css"  title="11" href="styles/themes/style11/stylesheet11.css" />
        <link rel="alternate stylesheet" type="text/css"  title="12" href="styles/themes/style12/stylesheet12.css" />
        <link rel="alternate stylesheet" type="text/css"  title="13" href="styles/themes/style13/stylesheet13.css" />
        <link rel="alternate stylesheet" type="text/css"  title="14" href="styles/themes/style14/stylesheet14.css" />
        <link rel="alternate stylesheet" type="text/css"  title="15" href="styles/themes/style15/stylesheet15.css" />
        <script src="inc/js/styleswitch.js" type="text/javascript">
        </script>
        <link rel="stylesheet" href="styles/flexslider.css" />
        <link rel="stylesheet" href="styles/fontawesome/font-awesome.min.css" />
        <link rel="stylesheet" href="styles/jquery-ui-1.10.3.custom.min.css" />
        <link rel="stylesheet" href="styles/mi-slider.css" />	
        <link rel="stylesheet" href="styles/chosen.css" />	
        <link rel="stylesheet" href="styles/rangeslider-classic.css" />
        <link rel="stylesheet" href="inc/elegant-font/style.css" />
     <link rel="stylesheet" href="demo/switcher.css" />
        <style>
			input {
    			border: 1.5px solid #030337;
    			border-radius: 4px;
    			padding: 7px 10px;
			}
			input[type=number] {
    			border: 1.5px solid #030337;
    			border-radius: 4px;
    			padding: 7px 0px;
			}
			input[type=submit] {
				background-color: #030337;
				color: white;
    			border-radius: 4px;
    			padding: 7px 0px;
    			margin: 0px 0px
			}
			input[type=radio] {
    			margin-right: 30px;
			}
			select {
    			border: 1.5px solid #030337;
    			border-radius: 4px;
    			padding: 6.5px 15px;
			}
		</style>
    </head>
    <body>
        <div id="site">
            <header id="header" class="wide-fat">
                <div class="container">
                    <div class="col-xs-12 col-sm-2 no-margin">
                        <div class="branding">
                            <h1 class="site-title">
                                <a href="index.php"><img src="images/site-logo.png" alt="Traveline" /> <span>Cally<span class="higlight">Air</span></span></a>
                            </h1>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-10 no-margin">
                        <div id="main-menu">
                            <nav class="navigation">
                                <ul class="hidden-xs hidden-sm hidden-md">
                                    <li class="menu-item destinations">
                                        <a href="bookflight.php"><i class="icon_group"></i> Manage Booking</a>
                                    </li>
                                    <li class="menu-item our-travel">
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="icon_globe_alt"></i> Online Check-in</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a data-toggle="modal" data-target="#AgentBox" href="#"><i class="fa fa-unlock"></i> Agent Login</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a data-toggle="modal" data-target="#CustomerBox" href="#"><i class="fa fa-lock"></i> Customer Login</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a href="phpmyadmin"><i class="icon_ribbon"></i> Admin Login</a>
                                    </li>
                                </ul></nav></div>
                    </div>
                </div>
            </header>
            <div class="modal fade" id="AgentBox" tabindex="-1" role="dialog"  aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <form action="\php\agent.php" method="post" onsubmit="return validation_agent()" name="agentlogin">
                                  <span>Agent Login</span>
                                <div class=" field-row">
                                    <input  placeholder="Username" id="user" name="user">
                                    <input  type="password" placeholder="Password" name="pass" id="pass">
                                    <div class="custom-checkbox-holder">
                                        <input class="custom-checkbox" type="checkbox" >
                                        <span>Remember me on this computer.</span>
                                    </div>
                                </div>
                                <button type="submit" class="button green" name="">Login Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="modal fade" id="CustomerBox" tabindex="-1" role="dialog"  aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <form action="\php\customer.php" method="post" onsubmit="return validation_customer()" name="customerlogin">
                                <span>Customer Login</span>
                                <div class=" field-row">
                                    <input  placeholder="Username" id="user" name="user">
                                    <input  type="password" placeholder="Password" id="pass" name="pass">
                                    <div class="custom-checkbox-holder">
                                        <input class="custom-checkbox" type="checkbox" >
                                        <span>Remember me on this computer.</span>
                                    </div>
                                </div>
                                <button type="submit" class="button green">Login Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
                                    <h2><center>ANSWER AVAILABLE INSTRUCTIONS</center></h2>

        <center>
            <form action="payment_details_form_handler.php" method="post">
			<h2>ENTER THE PAYMENT DETAILS</h2>
			<h3 style="margin-left: 30px"><u>Payment Summary</u></h3>
		<div>
            <?php
			if(isset($_POST['Pay_Now']))
			{
				$no_of_pass=$_SESSION['no_of_pass'];
				$flight_no=$_SESSION['flight_no'];
				$journey_date=$_SESSION['journey_date'];
				$class=$_SESSION['class'];
				$pnr=$_SESSION['pnr'];
				$payment_id=$_SESSION['payment_id'];
				$total_amount=$_SESSION['total_amount'];
				$payment_date=$_SESSION['payment_date'];
				$payment_mode=$_POST['payment_mode'];				

				require_once('connection.php');
				if($class=='economy')
				{
					$query="UPDATE available_flight SET seats_economy=seats_economy-? WHERE flight_no=? AND departure_date=?";
					$stmt=mysqli_prepare($con,$query);
					mysqli_stmt_bind_param($stmt,"iss",$no_of_pass,$flight_no,$journey_date);
					mysqli_stmt_execute($stmt);
					$affected_rows_1=mysqli_stmt_affected_rows($stmt);
					echo $affected_rows_1.'<br>';
					mysqli_stmt_close($stmt);
				}
				else if($class=='business')
				{
					$query="UPDATE available_flight SET seats_business=seats_business-? WHERE flight_no=? AND departure_date=?";
					$stmt=mysqli_prepare($con,$query);
					mysqli_stmt_bind_param($stmt,"iss",$no_of_pass,$flight_no,$journey_date);
					mysqli_stmt_execute($stmt);
					$affected_rows_1=mysqli_stmt_affected_rows($stmt);
					echo $affected_rows_1.'<br>';
					mysqli_stmt_close($stmt);
				}
				// mysqli_stmt_bind_result($stmt,$cnt);
				// mysqli_stmt_fetch($stmt);
				// echo $cnt;
				/*
				$response=@mysqli_query($dbc,$query);
				*/
				
			}
			else
			{
				echo "Payment request not received";
			}
            if($affected_rows_1==1)
				{
                    echo "Submit Success";
                    header('location:index.php');
					}
					
				else
				{
					echo "Submit Error";
					echo mysqli_error();
				}
				mysqli_close($con);
		?>

            
<center>            </center></div>
                                    <script src="inc/js/jquery-1.10.2.min.js"></script>
        <script src="inc/js/jquery-migrate-1.2.1.js"></script>
        <script src="inc/js/modernizr.custom.63321.js"></script>
        <script type="text/javascript" src="inc/js/jquery.flexslider-min.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.catslider.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.ui.datepicker.min.js"></script>	
        <script type="text/javascript" src="inc/js/masonry.min.js"></script>	
        <script type="text/javascript" src="inc/js/increase-decrease-qty.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.mixitup.min.js"></script>	
        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
        <script type="text/javascript" src="inc/js/google-map-infobox.js"></script>		
        <script type="text/javascript" src="inc/js/jquery.fitmaps.js"></script>	
        <script type="text/javascript" src="inc/js/chosen.jquery.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.screwdefaultbuttonsV2.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.mousewheel.min.js"></script>	
        <script type="text/javascript" src="inc/js/jQRangeSlider-min.js"></script>	
        <script type="text/javascript" src="inc/bootstrap/js/bootstrap.min.js"></script>		
        <script type="text/javascript" src="inc/js/jquery.raty.min.js"></script>	
        <script type="text/javascript" src="inc/js/custom.js"></script>	
        <script>
    var myDate = new Date();
    var hrs = myDate.getHours();

    var greet;

    if (hrs < 12)
        greet = 'Good Morning';
    else if (hrs >= 12 && hrs <= 17)
        greet = 'Good Afternoon';
    else if (hrs >= 17 && hrs <= 24)
        greet = 'Good Evening';

    document.getElementById('lblGreetings').innerHTML =
        '<b>' + greet + '</b> Friend';
</script>
<script>
  function validation_agent()  
            {  
                var id=document.agentlogin.user.value;  
                var ps=document.agentlogin.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("User Name and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
    function validation_customer()  
            {  
                var id=document.customerlogin.user.value;  
                var ps=document.customerlogin.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("User Name and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
  
                </script>
    </body>
</html>