<?php
session_start();
if(!$_GET["successfullypaid"]){
  header("Location: index.php");
  exit;
}else{
  $reference  =  $_GET["successfullypaid"];
  $amount = $_SESSION["total_amount"];;
}
?>
<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>CallyAir- Airline Agency</title>
        <link rel="stylesheet" href="inc/bootstrap/css/bootstrap.min.css" />
         <link rel="stylesheet" href="bookflight.css" /> 
       <link rel="alternate stylesheet" type="text/css"  title="02" href="styles/themes/style02/stylesheet02.css" />
        <link rel="alternate stylesheet" type="text/css"  title="03" href="styles/themes/style03/stylesheet03.css" />
        <link rel="alternate stylesheet" type="text/css"  title="04" href="styles/themes/style04/stylesheet04.css" />
        <link rel="alternate stylesheet" type="text/css"  title="05" href="styles/themes/style05/stylesheet05.css" />
        <link rel="alternate stylesheet" type="text/css"  title="06" href="styles/themes/style06/stylesheet06.css" />
        <link rel="alternate stylesheet" type="text/css"  title="07" href="styles/themes/style07/stylesheet07.css" />
        <link rel="alternate stylesheet" type="text/css"  title="08" href="styles/themes/style08/stylesheet08.css" />
        <link rel="alternate stylesheet" type="text/css"  title="09" href="styles/themes/style09/stylesheet09.css" />
        <link rel="alternate stylesheet" type="text/css"  title="10" href="styles/themes/style10/stylesheet10.css" />
        <link rel="alternate stylesheet" type="text/css"  title="11" href="styles/themes/style11/stylesheet11.css" />
        <link rel="alternate stylesheet" type="text/css"  title="12" href="styles/themes/style12/stylesheet12.css" />
        <link rel="alternate stylesheet" type="text/css"  title="13" href="styles/themes/style13/stylesheet13.css" />
        <link rel="alternate stylesheet" type="text/css"  title="14" href="styles/themes/style14/stylesheet14.css" />
        <link rel="alternate stylesheet" type="text/css"  title="15" href="styles/themes/style15/stylesheet15.css" />
        <script src="inc/js/styleswitch.js" type="text/javascript">
        </script>
        <link rel="stylesheet" href="styles/flexslider.css" />
        <link rel="stylesheet" href="styles/fontawesome/font-awesome.min.css" />
        <link rel="stylesheet" href="styles/jquery-ui-1.10.3.custom.min.css" />
        <link rel="stylesheet" href="styles/mi-slider.css" />	
        <link rel="stylesheet" href="styles/chosen.css" />	
        <link rel="stylesheet" href="styles/rangeslider-classic.css" />
        <link rel="stylesheet" href="inc/elegant-font/style.css" />
     <link rel="stylesheet" href="demo/switcher.css" />
        <style>
			button {
    			border: 1.5px solid #030337;
    			border-radius: 4px;
    			padding: 7px 100px;
			}
			button[type=number] {
    			border: 1.5px solid #030337;
    			border-radius: 4px;
    			padding: 7px 0px;
			}
			button[type=button] {
				background-color: #030337;
				color: white;
    			border-radius: 4px;
    			padding: 7px 613px;
    			margin: 0px 0px
			}
			button[type=radio] {
    			margin-right: 30px;
			}
			select {
    			border: 1.5px solid #030337;
    			border-radius: 4px;
    			padding: 6.5px 15px;
			}
		</style>
    </head>
    <body>
        <div id="site">
            <header id="header" class="wide-fat">
                <div class="container">
                    <div class="col-xs-12 col-sm-2 no-margin">
                        <div class="branding">
                            <h1 class="site-title">
                                <a href="index.php"><img src="images/site-logo.png" alt="Traveline" /> <span>Cally<span class="higlight">Air</span></span></a>
                            </h1>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-10 no-margin">
                        <div id="main-menu">
                            <nav class="navigation">
                                <ul class="hidden-xs hidden-sm hidden-md">
                                    <li class="menu-item destinations">
                                        <a href="bookflight.php"><i class="icon_group"></i> Manage Booking</a>
                                    </li>
                                    <li class="menu-item our-travel">
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="icon_globe_alt"></i> Online Check-in</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a data-toggle="modal" data-target="#AgentBox" href="#"><i class="fa fa-unlock"></i> Agent Login</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a data-toggle="modal" data-target="#CustomerBox" href="#"><i class="fa fa-lock"></i> Customer Login</a>
                                    </li>
                                    <li class="menu-item special-offers">
                                        <a href="phpmyadmin"><i class="icon_ribbon"></i> Admin Login</a>
                                    </li>
                                </ul></nav></div>
                    </div>
                </div>
            </header>
            <div class="modal fade" id="AgentBox" tabindex="-1" role="dialog"  aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <form action="\php\agent.php" method="post" onsubmit="return validation_agent()" name="agentlogin">
                                  <span>Agent Login</span>
                                <div class=" field-row">
                                    <input  placeholder="Username" id="user" name="user">
                                    <input  type="password" placeholder="Password" name="pass" id="pass">
                                    <div class="custom-checkbox-holder">
                                        <input class="custom-checkbox" type="checkbox" >
                                        <span>Remember me on this computer.</span>
                                    </div>
                                </div>
                                <button type="submit" class="button green" name="">Login Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="modal fade" id="CustomerBox" tabindex="-1" role="dialog"  aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <form action="\php\customer.php" method="post" onsubmit="return validation_customer()" name="customerlogin">
                                <span>Customer Login</span>
                                <div class=" field-row">
                                    <input  placeholder="Username" id="user" name="user">
                                    <input  type="password" placeholder="Password" id="pass" name="pass">
                                    <div class="custom-checkbox-holder">
                                        <input class="custom-checkbox" type="checkbox" >
                                        <span>Remember me on this computer.</span>
                                    </div>
                                </div>
                                <button type="submit" class="button green">Login Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
                                    <h2><center>PAYMENT SUCCESSFUL</center></h2>
        <center>
            <h3>Your payment went successfully, please check your email for your receipt. thank you</h3>
<td>Booking Code :  <?php echo $reference; ?> </td><br>
            <td>Amount Paid :<?php echo '&#8358';?> <?php echo $amount; ?> </td>
            
            </center></div>
                                    <script src="inc/js/jquery-1.10.2.min.js"></script>
        <script src="inc/js/jquery-migrate-1.2.1.js"></script>
        <script src="inc/js/modernizr.custom.63321.js"></script>
        <script type="text/javascript" src="inc/js/jquery.flexslider-min.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.catslider.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.ui.datepicker.min.js"></script>	
        <script type="text/javascript" src="inc/js/masonry.min.js"></script>	
        <script type="text/javascript" src="inc/js/increase-decrease-qty.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.mixitup.min.js"></script>	
        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>
        <script type="text/javascript" src="inc/js/google-map-infobox.js"></script>		
        <script type="text/javascript" src="inc/js/jquery.fitmaps.js"></script>	
        <script type="text/javascript" src="inc/js/chosen.jquery.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.screwdefaultbuttonsV2.js"></script>	
        <script type="text/javascript" src="inc/js/jquery.mousewheel.min.js"></script>	
        <script type="text/javascript" src="inc/js/jQRangeSlider-min.js"></script>	
        <script type="text/javascript" src="inc/bootstrap/js/bootstrap.min.js"></script>		
        <script type="text/javascript" src="inc/js/jquery.raty.min.js"></script>	
        <script type="text/javascript" src="inc/js/custom.js"></script>	
        
    </body>
</html>