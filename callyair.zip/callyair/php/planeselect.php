<html>
<?php 
$username = "root"; 
$password = "R29hb7mc2c$"; 
$database = "callyair"; 
$mysqli = new mysqli("127.1.2.3", $username, $password, $database); 
?>
</html>