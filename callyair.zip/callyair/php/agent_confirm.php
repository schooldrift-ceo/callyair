<html>
    
<?php      
    include('connection.php'); 
    session_start();
    session_destroy();
    session_start();
    $user = $_POST['user'];  
    $pass = $_POST['pass'];  
      
        $user = stripcslashes($user);  
        $pass = stripcslashes($pass);  
        $user = mysqli_real_escape_string($con, $user);  
        $pass = mysqli_real_escape_string($con, $pass);  
      
        $sql = "select *from agent where user = '$user' and pass = '$pass'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          
        if($count == 1){ 
           	$_SESSION['login_user']=$user;
            echo $_SESSION['login_user']." is logged in";
            header('location:../php/agent.php');
            }  
        else{  
            echo "Login Error";
            session_start();
            header('location:../agent_wrong.php');        }
        
?> 
    