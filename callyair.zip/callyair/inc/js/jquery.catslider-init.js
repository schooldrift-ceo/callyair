jQuery(document).ready(function($){

  jQuery( '#mi-slider' ).catslider();

});