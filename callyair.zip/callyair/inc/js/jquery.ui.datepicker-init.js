jQuery(document).ready(function($) {
	jQuery('.traveline_date_input').datepicker({
		dateFormat : 'd MM yy' // Date format http://jqueryui.com/datepicker/#date-formats
	});
});