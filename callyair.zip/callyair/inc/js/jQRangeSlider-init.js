jQuery(document).ready(function($){

	$("#sliderz").rangeSlider();


});