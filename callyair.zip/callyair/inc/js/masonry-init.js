jQuery(document).ready(function($){

	var $container = $('.destination-lists');
	// initialize
	$container.masonry({
	  itemSelector: '.destination'
	});


});