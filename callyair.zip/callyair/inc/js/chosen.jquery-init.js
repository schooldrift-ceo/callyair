jQuery(document).ready(function($){	
	
	
        
	
});	