jQuery(document).ready(function($){


	$("#map_canvas").fitMaps();


});