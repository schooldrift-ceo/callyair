jQuery(document).ready(function($){

  jQuery('#top-slider').flexslider({
	animation: "slide"
  });

  jQuery('#sliding-testimony').flexslider({
	animation: "fade",
	controlNav: false,
  });
  
});